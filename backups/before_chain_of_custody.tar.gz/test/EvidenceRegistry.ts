
import { expect } from "chai";
import { network } from "hardhat";

const { ethers } = await network.create();

describe("EvidenceRegistry", function () {
  async function deployRegistry() {
    const [owner, other] = await ethers.getSigners();
    const registry = await ethers.deployContract("EvidenceRegistry");

    return { registry, owner, other };
  }

  const evidenceId = "BEI-EV-001";

  const validHash = ethers.sha256(
    ethers.toUtf8Bytes("BEI-2026 simulated evidence")
  );

  const modifiedHash = ethers.sha256(
    ethers.toUtf8Bytes("BEI-2026 modified evidence")
  );

  it("SC-T01: Should register evidence successfully", async function () {
    const { registry, owner } = await deployRegistry();

    await expect(
      registry.registerEvidence(evidenceId, validHash)
    ).to.emit(registry, "EvidenceRegistered");

    expect(await registry.isEvidenceRegistered(evidenceId)).to.equal(true);

    const record = await registry.getEvidence(evidenceId);

    expect(record.id).to.equal(evidenceId);
    expect(record.sha256Hash).to.equal(validHash);
    expect(record.registeredBy).to.equal(owner.address);
    expect(record.exists).to.equal(true);
  });

  it("SC-T02: Should reject an empty evidence ID", async function () {
    const { registry } = await deployRegistry();

    await expect(
      registry.registerEvidence("", validHash)
    ).to.be.revertedWithCustomError(registry, "EmptyEvidenceId");
  });

  it("SC-T03: Should reject an empty SHA-256 hash", async function () {
    const { registry } = await deployRegistry();

    await expect(
      registry.registerEvidence(evidenceId, ethers.ZeroHash)
    ).to.be.revertedWithCustomError(registry, "EmptyEvidenceHash");
  });

  it("SC-T04: Should reject duplicate evidence registration", async function () {
    const { registry } = await deployRegistry();

    await registry.registerEvidence(evidenceId, validHash);

    await expect(
      registry.registerEvidence(evidenceId, modifiedHash)
    ).to.be.revertedWithCustomError(
      registry,
      "EvidenceAlreadyRegistered"
    );
  });

  it("SC-T05: Should return false for an unregistered evidence ID", async function () {
    const { registry } = await deployRegistry();

    expect(
      await registry.isEvidenceRegistered("BEI-EV-UNKNOWN")
    ).to.equal(false);
  });

  it("SC-T06: Should reject retrieving unregistered evidence", async function () {
    const { registry } = await deployRegistry();

    await expect(
      registry.getEvidence("BEI-EV-UNKNOWN")
    ).to.be.revertedWithCustomError(registry, "EvidenceNotFound");
  });

it("SC-T07: Should verify matching SHA-256 hash", async function () {
  const { registry, owner } = await deployRegistry();

  await registry.registerEvidence(evidenceId, validHash);

  const tx = await registry.verifyEvidence(evidenceId, validHash);
  const receipt = await tx.wait();

  const event = receipt?.logs
    .map((log) => {
      try {
        return registry.interface.parseLog(log);
      } catch {
        return null;
      }
    })
    .find((log) => log?.name === "EvidenceVerified");

  expect(event).to.not.equal(undefined);
  expect(event!.args.integrityMatched).to.equal(true);
  expect(event!.args.verifiedBy).to.equal(owner.address);
});

it("SC-T08: Should detect a mismatched SHA-256 hash", async function () {
  const { registry, owner } = await deployRegistry();

  await registry.registerEvidence(evidenceId, validHash);

  const tx = await registry.verifyEvidence(evidenceId, modifiedHash);
  const receipt = await tx.wait();

  const event = receipt?.logs
    .map((log) => {
      try {
        return registry.interface.parseLog(log);
      } catch {
        return null;
      }
    })
    .find((log) => log?.name === "EvidenceVerified");

  expect(event).to.not.equal(undefined);
  expect(event!.args.integrityMatched).to.equal(false);
  expect(event!.args.submittedHash).to.equal(modifiedHash);
  expect(event!.args.verifiedBy).to.equal(owner.address);
});

  it("SC-T09: Should reject verification of unregistered evidence", async function () {
    const { registry } = await deployRegistry();

    await expect(
      registry.verifyEvidence("BEI-EV-UNKNOWN", validHash)
    ).to.be.revertedWithCustomError(registry, "EvidenceNotFound");
  });

  it("SC-T10: Should preserve the original hash after verification", async function () {
    const { registry } = await deployRegistry();

    await registry.registerEvidence(evidenceId, validHash);

    await registry.verifyEvidence(evidenceId, modifiedHash);

    const record = await registry.getEvidence(evidenceId);

    expect(record.sha256Hash).to.equal(validHash);
  });
});
