
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.34;

/// @title EvidenceRegistry
/// @notice Registers digital evidence hashes and verifies their integrity.
/// @dev Evidence files remain off-chain. Only identifiers and SHA-256 hashes
///      are recorded on-chain.
contract EvidenceRegistry {
    struct EvidenceRecord {
        string evidenceId;
        bytes32 sha256Hash;
        address registeredBy;
        uint256 registeredAt;
        bool exists;
    }

    mapping(bytes32 => EvidenceRecord) private evidenceRecords;

    event EvidenceRegistered(
        string evidenceId,
        bytes32 indexed evidenceKey,
        bytes32 sha256Hash,
        address indexed registeredBy,
        uint256 registeredAt
    );

    event EvidenceVerified(
        string evidenceId,
        bytes32 indexed evidenceKey,
        bytes32 submittedHash,
        bool integrityMatched,
        address indexed verifiedBy,
        uint256 verifiedAt
    );

    error EmptyEvidenceId();
    error EmptyEvidenceHash();
    error EvidenceAlreadyRegistered(string evidenceId);
    error EvidenceNotFound(string evidenceId);

    /// @notice Register a digital evidence record.
    /// @param evidenceId Human-readable evidence identifier.
    /// @param sha256Hash SHA-256 digest of the evidence file.
    function registerEvidence(
        string calldata evidenceId,
        bytes32 sha256Hash
    ) external {
        if (bytes(evidenceId).length == 0) {
            revert EmptyEvidenceId();
        }

        if (sha256Hash == bytes32(0)) {
            revert EmptyEvidenceHash();
        }

        bytes32 evidenceKey = keccak256(bytes(evidenceId));

        if (evidenceRecords[evidenceKey].exists) {
            revert EvidenceAlreadyRegistered(evidenceId);
        }

        evidenceRecords[evidenceKey] = EvidenceRecord({
            evidenceId: evidenceId,
            sha256Hash: sha256Hash,
            registeredBy: msg.sender,
            registeredAt: block.timestamp,
            exists: true
        });

        emit EvidenceRegistered(
            evidenceId,
            evidenceKey,
            sha256Hash,
            msg.sender,
            block.timestamp
        );
    }

    /// @notice Retrieve a registered evidence record.
    function getEvidence(
        string calldata evidenceId
    )
        external
        view
        returns (
            string memory id,
            bytes32 sha256Hash,
            address registeredBy,
            uint256 registeredAt,
            bool exists
        )
    {
        bytes32 evidenceKey = keccak256(bytes(evidenceId));
        EvidenceRecord storage record = evidenceRecords[evidenceKey];

        if (!record.exists) {
            revert EvidenceNotFound(evidenceId);
        }

        return (
            record.evidenceId,
            record.sha256Hash,
            record.registeredBy,
            record.registeredAt,
            record.exists
        );
    }

    /// @notice Check whether an evidence identifier has been registered.
    function isEvidenceRegistered(
        string calldata evidenceId
    ) external view returns (bool) {
        bytes32 evidenceKey = keccak256(bytes(evidenceId));
        return evidenceRecords[evidenceKey].exists;
    }

    /// @notice Compare a supplied SHA-256 digest with the registered digest.
    /// @dev Anyone can verify; the result is recorded as an on-chain event.
    function verifyEvidence(
        string calldata evidenceId,
        bytes32 submittedHash
    ) external returns (bool integrityMatched) {
        bytes32 evidenceKey = keccak256(bytes(evidenceId));
        EvidenceRecord storage record = evidenceRecords[evidenceKey];

        if (!record.exists) {
            revert EvidenceNotFound(evidenceId);
        }

        integrityMatched = (record.sha256Hash == submittedHash);

        emit EvidenceVerified(
            evidenceId,
            evidenceKey,
            submittedHash,
            integrityMatched,
            msg.sender,
            block.timestamp
        );
    }
}
